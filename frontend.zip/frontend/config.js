// Configuración centralizada de la API en producción
const CONFIG = {
  // Endpoint productivo HTTPS en internet
  API_BASE_URL: 'https://latam.vks.cl/latam/api/v1/disruptions',
  
  // Ejemplos precargados para demostración en vivo ante el comité evaluador
  EXAMPLES: {
    'ABC123': {
      title: 'Caso Base: Conexión Perdida + Menor (Reglas R3 + R5)',
      desc: 'SCL ➔ LIM (Retraso 160m) con conexión a MEX perdida. Viaja menor Tomás (7 años), activando R5 que exige aprobación humana L2.'
    },
    'DELAY-ADULT': {
      title: 'Caso 2: Retraso Severo Solo Adultos (Regla R1)',
      desc: 'Retraso >= 180 min sin pasajeros menores. Reacomodo 100% determinístico sin intervención humana.'
    },
    'CONFLICT-SRC': {
      title: 'Caso 3: Conflicto de Fuentes y Degradación',
      desc: 'OPS_CORE reporta demora pero LEGACY_MIRROR reporta a tiempo. Resolución automática priorizando frescura y descartando degradadas.'
    },
    'CASH-COMP': {
      title: 'Caso 4: Solicitud de Compensación en Efectivo (Regla R4)',
      desc: 'Indemnización monetaria que requiere aprobación humana obligatoria por salvaguarda financiera.'
    }
  },

  // Respaldo de simulación en caso de desconexión puntual
  OFFLINE_MOCK: {
    bookingId: "ABC123",
    hasDisruption: true,
    rootCause: "DELAY_S1_160_MIN",
    missedConnection: true,
    requiresHumanApproval: true,
    humanReason: "El itinerario incluye un menor de edad (requiere validación de asientos contiguos y custodia)",
    humanCaseId: "HC-4471",
    entitlements: ["REBOOK_NO_FEE", "PRIORITY_HANDLING"],
    proposedOptions: [
      {
        optionId: "O1",
        flightNumber: "LA2412",
        origin: "LIM",
        destination: "MEX",
        date: "2026-09-16",
        departure: "08:15",
        fareDifference: 0.0,
        currency: "CLP",
        seatsAvailable: 4,
        policyRef: "POL-DELAY-2026-03",
        confidence: "HIGH"
      }
    ],
    customerExplanationMessage: "Hola María Silva, tu vuelo hacia LIM presentó una demora estimada de 160 minutos. Debido a esto, no será posible tomar la conexión programada. Hemos preseleccionado una alternativa sin costo en el vuelo LA2412 saliendo el 2026-09-16 a las 08:15. Dado que viajas con un menor de edad, un agente especializado está validando la asignación de asientos prioritarios para proteger a tu familia. Te contactaremos a la brevedad."
  }
};
