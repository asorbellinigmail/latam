// app.js - Conexión directa a https://latam.vks.cl/latam/api/v1/disruptions/
document.addEventListener('DOMContentLoaded', () => {
  const pnrInput = document.getElementById('pnrInput');
  const btnSearch = document.getElementById('btnSearch');
  const loader = document.getElementById('loader');
  const errorAlert = document.getElementById('errorAlert');
  const disruptionContent = document.getElementById('disruptionContent');
  const apiStatusText = document.getElementById('apiStatusText');
  const apiStatusPill = document.getElementById('apiStatusPill');

  btnSearch.addEventListener('click', () => loadBooking(pnrInput.value.trim()));
  pnrInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') loadBooking(pnrInput.value.trim());
  });

  // Helper para botones rápidos de casos
  window.selectPreset = function(pnr) {
    pnrInput.value = pnr;
    loadBooking(pnr);
  };

  // Carga inicial con ABC123
  loadBooking(pnrInput.value.trim());

  async function loadBooking(bookingId) {
    if (!bookingId) return;

    loader.classList.remove('hidden');
    errorAlert.classList.add('hidden');
    disruptionContent.classList.add('hidden');

    try {
      // Llamada real HTTPS a tu servidor en internet
      const response = await fetch(`${CONFIG.API_BASE_URL}/${bookingId}`, {
        method: 'GET',
        headers: { 
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Error en servidor: HTTP ${response.status}`);
      }

      const data = await response.json();
      apiStatusText.textContent = 'API en Vivo (Online)';
      apiStatusPill.querySelector('.status-dot').style.backgroundColor = '#22c55e';
      renderView(data);
    } catch (err) {
      console.warn('Fallo de conexión en vivo con https://latam.vks.cl. Evaluando caso:', err.message);
      apiStatusText.textContent = 'Modo Simulado / Fallback';
      apiStatusPill.querySelector('.status-dot').style.backgroundColor = '#f59e0b';
      
      // Si el PNR es ABC123 o uno de los ejemplos simulados
      const fallbackData = getCaseData(bookingId);
      renderView(fallbackData);
    } finally {
      loader.classList.add('hidden');
    }
  }

  function getCaseData(bookingId) {
    if (bookingId === 'DELAY-ADULT') {
      return {
        bookingId: "DELAY-ADULT",
        hasDisruption: true,
        rootCause: "DELAY_190_MIN",
        missedConnection: false,
        requiresHumanApproval: false,
        humanReason: null,
        humanCaseId: null,
        entitlements: ["REBOOK_NO_FEE", "MEAL_VOUCHER"],
        proposedOptions: [
          {
            optionId: "O1",
            flightNumber: "LA2412",
            origin: "LIM",
            destination: "MEX",
            date: "2026-09-16",
            departure: "08:15",
            fareDifference: 0.0,
            currency: "CLP",
            seatsAvailable: 3,
            policyRef: "POL-DELAY-2026-03"
          }
        ],
        customerExplanationMessage: "Estimado pasajero, su vuelo presenta un retraso de 190 minutos. Conforme a la política de protección R1, puede autogestionar su cambio de vuelo sin costo adicional."
      };
    } else if (bookingId === 'CASH-COMP') {
      return {
        bookingId: "CASH-COMP",
        hasDisruption: true,
        rootCause: "OVERBOOKING_OR_CANCELLATION",
        missedConnection: false,
        requiresHumanApproval: true,
        humanReason: "Solicitud de compensación económica en efectivo (Regla R4 - Requiere auditoría contable)",
        humanCaseId: "HC-9921",
        entitlements: ["CASH_COMPENSATION", "HOTEL_ACCOMMODATION"],
        proposedOptions: [],
        customerExplanationMessage: "Hemos recibido su solicitud de compensación monetaria. Un ejecutivo de compensaciones revisará la documentación y emitirá el depósito bancario."
      };
    }
    return CONFIG.OFFLINE_MOCK;
  }

  function renderView(data) {
    disruptionContent.classList.remove('hidden');

    // Mensaje empático
    document.getElementById('customerMessageText').textContent = data.customerExplanationMessage;

    // Alerta de supervisión humana (R5 o R4)
    const minorBanner = document.getElementById('minorEscalationBanner');
    if (data.requiresHumanApproval) {
      minorBanner.classList.remove('hidden');
      document.getElementById('minorEscalationReason').textContent = data.humanReason;
      document.getElementById('humanCaseBadge').textContent = data.humanCaseId || 'HC-4471';
    } else {
      minorBanner.classList.add('hidden');
    }

    // Renderizar segmentos
    renderSegments(data);

    // Políticas
    const list = document.getElementById('entitlementsList');
    list.innerHTML = '';
    (data.entitlements || []).forEach(ent => {
      const li = document.createElement('li');
      if (ent === 'REBOOK_NO_FEE') {
        li.innerHTML = '<strong>Reacomodo sin costo (R3/R1):</strong> Tienes derecho a cambiar de vuelo a costo $0.';
      } else if (ent === 'PRIORITY_HANDLING') {
        li.innerHTML = '<strong>Atención prioritaria (R5):</strong> Custodia y protección de asignación conjunta de asientos para el menor de edad.';
      } else if (ent === 'CASH_COMPENSATION') {
        li.innerHTML = '<strong>Compensación en efectivo (R4):</strong> Sujeto a validación documental por un agente.';
      } else {
        li.innerHTML = `<strong>${ent}</strong>`;
      }
      list.appendChild(li);
    });

    // Opciones de vuelo
    renderOptions(data);
  }

  function renderSegments(data) {
    const timeline = document.getElementById('segmentsTimeline');
    if (data.bookingId === 'DELAY-ADULT') {
      timeline.innerHTML = `
        <div class="segment-card">
          <div class="segment-flight">LA500</div>
          <div class="segment-times">
            <div class="time-box">
              <div class="city">SCL (Santiago)</div>
              <div class="hour">Prog: 14:30</div>
              <div class="hour delayed">Real: 17:40 (+190m)</div>
            </div>
            <div>➔</div>
            <div class="time-box">
              <div class="city">LIM (Lima)</div>
              <div class="hour">Prog: 17:55</div>
              <div class="hour delayed">Estimada: 21:05</div>
            </div>
          </div>
          <div><span class="badge badge-delayed">Retraso >= 180m</span></div>
        </div>
      `;
      return;
    }

    timeline.innerHTML = `
      <div class="segment-card">
        <div class="segment-flight">LA500</div>
        <div class="segment-times">
          <div class="time-box">
            <div class="city">SCL (Santiago)</div>
            <div class="hour">Prog: 14:30</div>
            <div class="hour delayed">Real: 17:10 (+160m)</div>
          </div>
          <div>➔</div>
          <div class="time-box">
            <div class="city">LIM (Lima)</div>
            <div class="hour">Prog: 17:55</div>
            <div class="hour delayed">Estimada: 20:35</div>
          </div>
        </div>
        <div>
          <span class="badge badge-delayed">Retrasado 160m</span>
        </div>
      </div>

      <div class="segment-card" style="border-left: 4px solid #ef4444;">
        <div class="segment-flight">LA2410</div>
        <div class="segment-times">
          <div class="time-box">
            <div class="city">LIM (Lima)</div>
            <div class="hour">Prog: 19:05</div>
          </div>
          <div>➔</div>
          <div class="time-box">
            <div class="city">MEX (Ciudad de México)</div>
            <div class="hour">Prog: 23:40</div>
          </div>
        </div>
        <div>
          <span class="badge badge-missed">Conexión Imposible</span>
        </div>
      </div>
    `;
  }

  function renderOptions(data) {
    const container = document.getElementById('optionsList');
    container.innerHTML = '';

    if (!data.proposedOptions || data.proposedOptions.length === 0) {
      container.innerHTML = '<p class="text-muted">No hay vuelos sugeridos automáticos. Esperando revisión o contacto del agente.</p>';
      return;
    }

    data.proposedOptions.forEach(opt => {
      const card = document.createElement('div');
      card.className = 'option-item recommended';
      const flightNum = opt.flightNumber || opt.flight_number;
      const seats = opt.seatsAvailable !== undefined ? opt.seatsAvailable : opt.seats_available;
      const optId = opt.optionId || opt.option_id;

      card.innerHTML = `
        <div class="option-header">
          <div>
            <span class="badge badge-ontime" style="margin-right: 0.5rem;">Sugerido</span>
            <strong>Vuelo ${flightNum}</strong>
          </div>
          <span class="price-tag">$0 CLP</span>
        </div>
        <div style="font-size: 0.95rem; margin: 0.5rem 0;">
          <strong>Ruta:</strong> ${opt.origin} ➔ ${opt.destination}<br>
          <strong>Salida:</strong> ${opt.date} a las ${opt.departure} hrs.<br>
          <strong>Cupos disponibles:</strong> ${seats} asientos.
        </div>
        <div style="margin-top: 0.75rem;">
          ${data.requiresHumanApproval ? `
            <button class="btn btn-disabled" disabled style="width: 100%;">
              🔒 Auto-reacomodo bloqueado por menor de edad (Validación L2 requerida)
            </button>
          ` : `
            <button class="btn btn-primary" onclick="proceedToRebooking('${optId}', '${data.bookingId}')" style="width: 100%;">
              Aceptar y Emitir este Vuelo
            </button>
          `}
        </div>
      `;
      container.appendChild(card);
    });
  }
});

window.proceedToRebooking = function(optionId, bookingId) {
  window.location.href = `rebooking.html?optionId=${optionId}&bookingId=${bookingId || 'ABC123'}`;
};
